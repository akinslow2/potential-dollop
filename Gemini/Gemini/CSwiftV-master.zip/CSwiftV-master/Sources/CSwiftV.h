//
//  CSwiftVIOS.h
//  CSwiftVIOS
//
//  Created by Daniel Haight on 04/05/2015.
//  Copyright (c) 2015 ManyThings. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for CSwiftV.
FOUNDATION_EXPORT double CSwiftVVersionNumber;

//! Project version string for CSwiftV.
FOUNDATION_EXPORT const unsigned char CSwiftVVersionString[];

// In this header, you should import all the public headers of your framework
// using statements like #import <CSwiftV/PublicHeader.h>
